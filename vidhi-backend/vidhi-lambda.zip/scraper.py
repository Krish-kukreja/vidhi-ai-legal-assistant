import copy
import json
import os
import logging

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, NoSuchElementException

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class MySchemeScraper:
    def __init__(self):
        self.myscheme_url = 'https://rules.myscheme.in/'
        options = webdriver.FirefoxOptions()
        options.page_load_strategy = 'eager' # Don't wait for all images/assets context to load
        self.driver = webdriver.Firefox(options=options)
        self.driver.set_page_load_timeout(45) # 45 sec timeout instead of 300 sec

    def get_scheme_links(self):
        self.driver.get(self.myscheme_url)
        scheme_links = []

        try:
            WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located((By.ID, "__next")))
            import time
            time.sleep(3) # Wait for page dynamic content to fully load

            tbody = self.driver.find_element(By.ID, '__next').find_element(By.TAG_NAME, 'tbody')
            num_rows = len(tbody.find_elements(By.TAG_NAME, 'tr'))

            for i in range(num_rows):
                retries = 3
                while retries > 0:
                    try:
                        # Re-fetch row on each iteration to avoid stale elements
                        tbody = self.driver.find_element(By.ID, '__next').find_element(By.TAG_NAME, 'tbody')
                        row = tbody.find_elements(By.TAG_NAME, 'tr')[i]
                        table_rows = row.find_elements(By.TAG_NAME, 'td')
                        
                        if len(table_rows) >= 3:
                            result_details_dict = {
                                'sr_no': table_rows[0].text,
                                'scheme_name': table_rows[1].text.replace('\nCheck Eligibility', ''),
                                'scheme_link': table_rows[2].find_element(By.TAG_NAME, 'a').get_attribute('href')
                            }
                            scheme_links.append(result_details_dict)
                        break
                    except Exception as e:
                        retries -= 1
                        time.sleep(1)
                        if retries == 0:
                            logging.error(f"Failed to fetch row {i} due to: {e}")

        except TimeoutException:
            logging.error("Timeout while waiting for page to load")
        except NoSuchElementException as e:
            logging.error(f"Element not found: {e}")

        return scheme_links

    def get_scheme_details(self, scheme_links):
        for scheme in scheme_links:
            try:
                self.driver.get(scheme['scheme_link'])
                WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located((By.ID, "__next")))

                # Extract tags with exception handling
                try:
                    tags_elements = self.driver.find_elements(By.XPATH, '//div[@id="tags"]/div')
                    scheme['tags'] = [i.text for i in tags_elements]
                except NoSuchElementException:
                    scheme['tags'] = []

                # Extract details with exception handling
                try:
                    scheme['details'] = self.driver.find_element(By.ID, 'details').text
                except NoSuchElementException:
                    scheme['details'] = 'Not Available'

                # Extract benefits with exception handling
                try:
                    scheme['benefits'] = self.driver.find_element(By.ID, 'benefits').text
                except NoSuchElementException:
                    scheme['benefits'] = 'Not Available'

                # Extract eligibility with exception handling
                try:
                    scheme['eligibility'] = self.driver.find_element(By.ID, 'eligibility').text
                except NoSuchElementException:
                    scheme['eligibility'] = 'Not Available'

                # Extract application process with exception handling
                try:
                    scheme['application_process'] = self.driver.find_element(By.ID, 'application-process').text
                except NoSuchElementException:
                    scheme['application_process'] = 'Not Available'

                # Extract documents required with exception handling
                try:
                    scheme['documents_required'] = self.driver.find_element(By.ID, 'documents-required').text
                except NoSuchElementException:
                    scheme['documents_required'] = 'Not Available'

            except TimeoutException:
                logging.error(f"Timeout while waiting for scheme page to load: {scheme['scheme_link']}")
            except Exception as e:
                logging.error(f"An error occurred for scheme page {scheme['scheme_link']}: {e}")

    def download(self):
        scheme_links = self.get_scheme_links()
        self.get_scheme_details(scheme_links)
        self.driver.quit()
        return scheme_links


def scrape_and_store_to_json_file():
    """Scrape government schemes and store to JSON file"""
    try:
        download_path = os.path.join(os.path.dirname(__file__), 'myschemes_scraped.json')
        scraper = MySchemeScraper()
        scraped_scheme_details = scraper.download()
        with open(download_path, 'w', encoding='utf-8') as file:
            json.dump(scraped_scheme_details, file, indent=2, ensure_ascii=False)
        logging.info(f"Successfully scraped {len(scraped_scheme_details)} schemes")
        return scraped_scheme_details
    except Exception as e:
        logging.error(f"Error scraping schemes: {e}")
        raise e


def scrape_and_upload_to_s3():
    """Scrape government schemes and upload to S3 (AWS version)"""
    try:
        import boto3
        
        scraper = MySchemeScraper()
        scraped_scheme_details = scraper.download()
        
        # Upload to S3
        s3_client = boto3.client('s3', region_name='ap-south-1')
        s3_client.put_object(
            Bucket='vidhi-documents-prod',
            Key='schemes/myschemes_scraped.json',
            Body=json.dumps(scraped_scheme_details, indent=2, ensure_ascii=False),
            ContentType='application/json'
        )
        
        logging.info(f"Successfully scraped and uploaded {len(scraped_scheme_details)} schemes to S3")
        return scraped_scheme_details
    except Exception as e:
        logging.error(f"Error scraping and uploading schemes: {e}")
        raise e


if __name__ == "__main__":
    # Run scraper
    scrape_and_store_to_json_file()
